Proceso DesencolarEjecutarCPU
    Definir MEMORIA_NODOS Como Cadena
    Dimension MEMORIA_NODOS[100, 5] 
    Definir cabeza, frente, tope, ultimoLibre, i Como Entero
    Definir nodoAEliminar, actual Como Entero
    
    Para i <- 1 Hasta 100 Hacer
        MEMORIA_NODOS[i, 1] <- ""
        MEMORIA_NODOS[i, 5] <- "0"
    FinPara
    
    MEMORIA_NODOS[1, 1] <- "101"
    MEMORIA_NODOS[1, 2] <- "Calculadora"
    MEMORIA_NODOS[1, 5] <- "2"
    
    MEMORIA_NODOS[2, 1] <- "102"
    MEMORIA_NODOS[2, 2] <- "Paint"
    MEMORIA_NODOS[2, 5] <- "0"
    
    frente <- 1
    
    Si frente = 0 Entonces
        Escribir "No hay procesos esperando en la CPU."
    Sino
        nodoAEliminar <- frente
        Escribir "EJECUTANDO -> ID: ", MEMORIA_NODOS[nodoAEliminar, 1], " | Tarea: ", MEMORIA_NODOS[nodoAEliminar, 2]
        
        frente <- ConvertirANumero(MEMORIA_NODOS[frente, 5])
        MEMORIA_NODOS[nodoAEliminar, 1] <- ""
        MEMORIA_NODOS[nodoAEliminar, 5] <- "0"
        Escribir "Ejecuci�n finalizada. El proceso del frente fue retirado de la Cola."
    FinSi
    
    Escribir ""
    Escribir "*** RECORRIDO DE VERIFICACI�N ***"
    actual <- frente
    Si actual = 0 Entonces
        Escribir "La Cola quedo totalmente vacia (Frente apunta a 0)"
    Sino
        Mientras actual <> 0 Hacer
            Escribir "Direcci�n [", actual, "] -> ID: ", MEMORIA_NODOS[actual, 1], " | Sigue esperando: ", MEMORIA_NODOS[actual, 2], " | Siguiente apunta a: ", MEMORIA_NODOS[actual, 5]
            actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
        FinMientras
    FinSi
FinProceso