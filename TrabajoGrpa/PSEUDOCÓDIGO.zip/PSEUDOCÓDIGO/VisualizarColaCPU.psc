Proceso VisualizarColaCPU
    Definir MEMORIA_NODOS Como Cadena
    Dimension MEMORIA_NODOS[100, 5] 
    Definir cabeza, frente, tope, ultimoLibre, i Como Entero
    Definir actual, pos Como Entero
    
    Para i <- 1 Hasta 100 Hacer
        MEMORIA_NODOS[i, 1] <- ""
        MEMORIA_NODOS[i, 5] <- "0"
    FinPara
    
    MEMORIA_NODOS[1, 1] <- "105"
    MEMORIA_NODOS[1, 2] <- "Word"
    MEMORIA_NODOS[1, 3] <- "5"
    MEMORIA_NODOS[1, 5] <- "2"
    
    MEMORIA_NODOS[2, 1] <- "106"
    MEMORIA_NODOS[2, 2] <- "Excel"
    MEMORIA_NODOS[2, 3] <- "3"
    MEMORIA_NODOS[2, 5] <- "0"
    
    frente <- 1
    
    Escribir "*** RECORRIDO DE VERIFICACI�N (VISUALIZAR COLA CPU) ***"
    Si frente = 0 Entonces
        Escribir "Cola de CPU vac�a."
    Sino
        actual <- frente
        pos <- 1
        Mientras actual <> 0 Hacer
            Escribir "Posici�n en Cola [", pos, "] | Direcci�n [", actual, "] -> ID: ", MEMORIA_NODOS[actual, 1], " | Nombre: ", MEMORIA_NODOS[actual, 2], " | Prioridad: ", MEMORIA_NODOS[actual, 3], " | Enlace Siguiente: ", MEMORIA_NODOS[actual, 5]
            actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
            pos <- pos + 1
        FinMientras
    FinSi
FinProceso