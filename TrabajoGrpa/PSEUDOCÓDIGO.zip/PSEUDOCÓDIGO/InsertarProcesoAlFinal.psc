Proceso InsertarProcesoAlFinal
	Definir MEMORIA_NODOS Como Cadena
	Dimensionar MEMORIA_NODOS(100,5)
	Definir cabeza, frente, tope, ultimoLibre, i Como Entero
	Definir nuevoNodo, actual Como Entero
	Definir nuevoId, nuevoNombre, nuevaPrioridad Como Cadena
	Para i<-1 Hasta 100 Hacer
		MEMORIA_NODOS[i,1]<-''
		MEMORIA_NODOS[i,5]<-'0'
	FinPara
	MEMORIA_NODOS[1,1]<-'101'
	MEMORIA_NODOS[1,2]<-'Excel'
	MEMORIA_NODOS[1,3]<-'3'
	MEMORIA_NODOS[1,4]<-'LISTO'
	MEMORIA_NODOS[1,5]<-'0'
	cabeza <- 1
	ultimoLibre <- 2
	Escribir '*** REGISTRO DE NUEVO PROCESO (AL FINAL) ***'
	Escribir 'Ingrese ID del nuevo proceso:'
	Leer nuevoId
	Escribir 'Ingrese Nombre del proceso:'
	Leer nuevoNombre
	Escribir 'Ingrese Prioridad:'
	Leer nuevaPrioridad
	nuevoNodo <- ultimoLibre
	MEMORIA_NODOS[nuevoNodo,1]<-nuevoId
	MEMORIA_NODOS[nuevoNodo,2]<-nuevoNombre
	MEMORIA_NODOS[nuevoNodo,3]<-nuevaPrioridad
	MEMORIA_NODOS[nuevoNodo,4]<-'LISTO'
	MEMORIA_NODOS[nuevoNodo,5]<-'0'
	ultimoLibre <- ultimoLibre+1
	Si cabeza=0 Entonces
		cabeza <- nuevoNodo
	SiNo
		actual <- cabeza
		Mientras MEMORIA_NODOS[actual,5]<>'0' Hacer
			actual <- ConvertirANumero(MEMORIA_NODOS[actual,5])
		FinMientras
		MEMORIA_NODOS[actual,5]<-ConvertirATexto(nuevoNodo)
	FinSi
	Escribir ''
	Escribir 'Proceso registrado y enlazado exitosamente al final.'
	Escribir ''
	Escribir '*** RECORRIDO DE VERIFICACI�N ***'
	actual <- cabeza
	Mientras actual<>0 Hacer
		Escribir 'Direcci�n [', actual, '] -> ID: ', MEMORIA_NODOS[actual,1], ' | Nombre: ', MEMORIA_NODOS[actual,2], ' | Siguiente apunta a: ', MEMORIA_NODOS[actual,5]
		actual <- ConvertirANumero(MEMORIA_NODOS[actual,5])
	FinMientras
FinProceso
