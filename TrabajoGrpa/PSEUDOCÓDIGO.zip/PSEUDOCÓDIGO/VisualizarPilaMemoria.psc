Proceso VisualizarPilaMemoria
    Definir MEMORIA_NODOS Como Cadena
    Dimension MEMORIA_NODOS[100, 5] 
    Definir cabeza, frente, tope, ultimoLibre, i Como Entero
    Definir actual, totalKB Como Entero
    
    Para i <- 1 Hasta 100 Hacer
        MEMORIA_NODOS[i, 1] <- ""
        MEMORIA_NODOS[i, 5] <- "0"
    FinPara
    
    MEMORIA_NODOS[1, 1] <- "301"
    MEMORIA_NODOS[1, 2] <- "Antivirus"
    MEMORIA_NODOS[1, 3] <- "1024"
    MEMORIA_NODOS[1, 5] <- "2"
    
    MEMORIA_NODOS[2, 1] <- "302"
    MEMORIA_NODOS[2, 2] <- "Explorador"
    MEMORIA_NODOS[2, 3] <- "512"
    MEMORIA_NODOS[2, 5] <- "0"
    
    tope <- 1
    
    Escribir "*** RECORRIDO DE VERIFICACI�N (MAPA DE PILA) ***"
    Si tope = 0 Entonces
        Escribir "No hay memoria reservada (Pila vac�a)."
    Sino
        actual <- tope
        totalKB <- 0
        Mientras actual <> 0 Hacer
            Escribir "Direcci�n [", actual, "] -> CIMA DE MEMORIA -> Proceso: ", MEMORIA_NODOS[actual, 2], " | Consumo: ", MEMORIA_NODOS[actual, 3], " KB | Enlace Abajo: ", MEMORIA_NODOS[actual, 5]
            totalKB <- totalKB + ConvertirANumero(MEMORIA_NODOS[actual, 3])
            actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
        FinMientras
        Escribir "Total RAM ocupada: ", totalKB, " KB"
    FinSi
FinProceso