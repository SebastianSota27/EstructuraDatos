Proceso ModificarPrioridadLista
    Definir MEMORIA_NODOS Como Cadena
    Dimension MEMORIA_NODOS[100, 5] 
    Definir cabeza, frente, tope, ultimoLibre, i Como Entero
    Definir actual Como Entero
    Definir idTarget, nuevaPrioridad Como Cadena
    Definir encontrado Como Logico
    
    Para i <- 1 Hasta 100 Hacer
        MEMORIA_NODOS[i, 1] <- ""
        MEMORIA_NODOS[i, 5] <- "0"
    FinPara
    
    MEMORIA_NODOS[1, 1] <- "101"
    MEMORIA_NODOS[1, 2] <- "Word"
    MEMORIA_NODOS[1, 3] <- "3"
    MEMORIA_NODOS[1, 5] <- "0"
    cabeza <- 1
    
    Escribir "Ingrese ID del proceso a modificar (Prueba con 101):"
    Leer idTarget
    
    actual <- cabeza
    encontrado <- Falso
    
    Mientras actual <> 0 Y encontrado = Falso Hacer
        Si MEMORIA_NODOS[actual, 1] = idTarget Entonces
            encontrado <- Verdadero
            Escribir "Proceso encontrado: ", MEMORIA_NODOS[actual, 2]
            Escribir "Ingrese nueva prioridad:"
            Leer nuevaPrioridad
            MEMORIA_NODOS[actual, 3] <- nuevaPrioridad
            Escribir "Prioridad modificada con �xito."
        Sino
            actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
        FinSi
    FinMientras
    
    Si encontrado = Falso Entonces
        Escribir "Proceso no existe."
    FinSi
    
    Escribir ""
    Escribir "*** RECORRIDO DE VERIFICACI�N ***"
    actual <- cabeza
    Mientras actual <> 0 Hacer
        Escribir "Direcci�n [", actual, "] -> ID: ", MEMORIA_NODOS[actual, 1], " | Nombre: ", MEMORIA_NODOS[actual, 2], " | NUEVA Prioridad: ", MEMORIA_NODOS[actual, 3]
        actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
    FinMientras
FinProceso