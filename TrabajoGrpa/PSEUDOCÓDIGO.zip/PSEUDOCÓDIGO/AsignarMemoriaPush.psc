Proceso AsignarMemoriaPush
    Definir MEMORIA_NODOS Como Cadena
    Dimension MEMORIA_NODOS[100, 5] 
    Definir cabeza, frente, tope, ultimoLibre, i Como Entero
    Definir nuevoBloque, actual Como Entero
    Definir idProc, nomProc, tamKB Como Cadena
    
    Para i <- 1 Hasta 100 Hacer
        MEMORIA_NODOS[i, 1] <- ""
        MEMORIA_NODOS[i, 5] <- "0"
    FinPara
    
    MEMORIA_NODOS[1, 1] <- "99"
    MEMORIA_NODOS[1, 2] <- "Kernel"
    MEMORIA_NODOS[1, 3] <- "2048"
    MEMORIA_NODOS[1, 5] <- "0"
    
    tope <- 1
    ultimoLibre <- 2
    
    Escribir "=== OPERACI�N APILAR MEMORIA (PUSH) ==="
    Escribir "Ingrese ID del proceso:"
    Leer idProc
    Escribir "Ingrese Nombre del proceso:"
    Leer nomProc
    Escribir "Ingrese cantidad de KB a asignar:"
    Leer tamKB
    
    nuevoBloque <- ultimoLibre
    MEMORIA_NODOS[nuevoBloque, 1] <- idProc
    MEMORIA_NODOS[nuevoBloque, 2] <- nomProc
    MEMORIA_NODOS[nuevoBloque, 3] <- tamKB
    
    MEMORIA_NODOS[nuevoBloque, 5] <- ConvertirATexto(tope)
    tope <- nuevoBloque
    ultimoLibre <- ultimoLibre + 1
    
    Escribir "Bloque de memoria apilado."
    Escribir ""
    Escribir "*** RECORRIDO DE VERIFICACI�N (PILA LIFO) ***"
    actual <- tope
    Mientras actual <> 0 Hacer
        Escribir "Direcci�n [", actual, "] (Hacia abajo) -> Proceso: ", MEMORIA_NODOS[actual, 2], " | Espacio: ", MEMORIA_NODOS[actual, 3], " KB | Abajo apunta a: ", MEMORIA_NODOS[actual, 5]
        actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
    FinMientras
FinProceso