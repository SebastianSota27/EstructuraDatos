Proceso EliminarProcesoLista
    Definir MEMORIA_NODOS Como Cadena
    Dimension MEMORIA_NODOS[100, 5] 
    Definir cabeza, frente, tope, ultimoLibre, i Como Entero
    Definir actual, anterior Como Entero
    Definir encontrado Como Logico
    Definir idTarget Como Cadena
    
    Para i <- 1 Hasta 100 Hacer
        MEMORIA_NODOS[i, 1] <- ""
        MEMORIA_NODOS[i, 5] <- "0"
    FinPara
    
    MEMORIA_NODOS[1, 1] <- "101"
    MEMORIA_NODOS[1, 2] <- "Word"
    MEMORIA_NODOS[1, 5] <- "2"
    MEMORIA_NODOS[2, 1] <- "102"
    MEMORIA_NODOS[2, 2] <- "Excel"
    MEMORIA_NODOS[2, 5] <- "0"
    
    cabeza <- 1
    ultimoLibre <- 3
    
    Escribir "Ingrese ID a eliminar (Prueba con 101 o 102):"
    Leer idTarget
    
    actual <- cabeza
    anterior <- 0
    encontrado <- Falso
    
    Mientras actual <> 0 Y encontrado = Falso Hacer
        Si MEMORIA_NODOS[actual, 1] = idTarget Entonces
            encontrado <- Verdadero
            Si actual = cabeza Entonces
                cabeza <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
            Sino
                MEMORIA_NODOS[anterior, 5] <- MEMORIA_NODOS[actual, 5]
            FinSi
            MEMORIA_NODOS[actual, 1] <- ""
            MEMORIA_NODOS[actual, 5] <- "0"
            Escribir "Proceso eliminado correctamente de la memoria."
        Sino
            anterior <- actual
            actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
        FinSi
    FinMientras
    
    Si encontrado = Falso Entonces
        Escribir "ID no encontrado."
    FinSi
    
    Escribir ""
    Escribir "*** RECORRIDO DE VERIFICACI�N ***"
    actual <- cabeza
    Si actual = 0 Entonces
        Escribir "La lista quedo totalmente vacia (Cabeza apunta a 0)"
    Sino
        Mientras actual <> 0 Hacer
            Escribir "Direcci�n [", actual, "] -> ID: ", MEMORIA_NODOS[actual, 1], " | Nombre: ", MEMORIA_NODOS[actual, 2], " | Siguiente apunta a: ", MEMORIA_NODOS[actual, 5]
            actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
        FinMientras
    FinSi
FinProceso