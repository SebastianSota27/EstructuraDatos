Proceso ListarProcesosLista
    Definir MEMORIA_NODOS Como Cadena
    Dimension MEMORIA_NODOS[100, 5] 
    Definir cabeza, frente, tope, ultimoLibre, i Como Entero
    Definir actual Como Entero
    
    Para i <- 1 Hasta 100 Hacer
        MEMORIA_NODOS[i, 1] <- ""
        MEMORIA_NODOS[i, 5] <- "0"
    FinPara
    
    MEMORIA_NODOS[1, 1] <- "101"
    MEMORIA_NODOS[1, 2] <- "Word"
    MEMORIA_NODOS[1, 3] <- "4"
    MEMORIA_NODOS[1, 4] <- "LISTO"
    MEMORIA_NODOS[1, 5] <- "2"
    
    MEMORIA_NODOS[2, 1] <- "102"
    MEMORIA_NODOS[2, 2] <- "Excel"
    MEMORIA_NODOS[2, 3] <- "5"
    MEMORIA_NODOS[2, 4] <- "EJECUTANDO"
    MEMORIA_NODOS[2, 5] <- "0"
    
    cabeza <- 1
    
    Escribir "*** RECORRIDO DE VERIFICACI�N (LISTADO) ***"
    Si cabeza = 0 Entonces
        Escribir "La lista est� vac�a."
    Sino
        actual <- cabeza
        Mientras actual <> 0 Hacer
            Escribir "Direcci�n [", actual, "] -> ID: ", MEMORIA_NODOS[actual, 1], " | Tarea: ", MEMORIA_NODOS[actual, 2], " | Prioridad: ", MEMORIA_NODOS[actual, 3], " | Siguiente apunta a: ", MEMORIA_NODOS[actual, 5]
            actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
        FinMientras
    FinSi
FinProceso