Proceso BuscarProcesoLista
    Definir MEMORIA_NODOS Como Cadena
    Dimension MEMORIA_NODOS[100, 5] 
    Definir cabeza, frente, tope, ultimoLibre, i Como Entero
    Definir actual Como Entero
    Definir buscado Como Cadena
    Definir encontrado Como Logico
    
    Para i <- 1 Hasta 100 Hacer
        MEMORIA_NODOS[i, 1] <- ""
        MEMORIA_NODOS[i, 5] <- "0"
    FinPara
    
    MEMORIA_NODOS[1, 1] <- "101"
    MEMORIA_NODOS[1, 2] <- "Word"
    MEMORIA_NODOS[1, 4] <- "LISTO"
    MEMORIA_NODOS[1, 5] <- "0"
    cabeza <- 1
    
    Escribir "Ingrese ID o Nombre a buscar (Prueba con 101 o Word):"
    Leer buscado
    
    actual <- cabeza
    encontrado <- Falso
    
    Escribir ""
    Escribir "*** RECORRIDO DE VERIFICACI�N ***"
    Mientras actual <> 0 Hacer
        Si MEMORIA_NODOS[actual, 1] = buscado O MEMORIA_NODOS[actual, 2] = buscado Entonces
            Escribir "COINCIDENCIA ENCONTRADA"
            Escribir "Direcci�n [", actual, "] -> ID: ", MEMORIA_NODOS[actual, 1], " | Nombre: ", MEMORIA_NODOS[actual, 2], " | Estado: ", MEMORIA_NODOS[actual, 4]
            encontrado <- Verdadero
        Sino
            Escribir "Revisando Direcci�n [", actual, "]... No coincide."
        FinSi
        actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
    FinMientras
    
    Si encontrado = Falso Entonces
        Escribir "El elemento buscado no existe en la lista enlazada."
    FinSi
FinProceso