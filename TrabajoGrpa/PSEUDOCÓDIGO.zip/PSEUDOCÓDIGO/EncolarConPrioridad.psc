Proceso EncolarConPrioridad
    Definir MEMORIA_NODOS Como Cadena
    Dimension MEMORIA_NODOS[100, 5] 
    Definir cabeza, frente, tope, ultimoLibre, i Como Entero
    Definir nuevoNodo, actual, anterior Como Entero
    Definir nuevoId, nuevoNombre, nuevaPrioridad Como Cadena
    
    Para i <- 1 Hasta 100 Hacer
        MEMORIA_NODOS[i, 1] <- ""
        MEMORIA_NODOS[i, 5] <- "0"
    FinPara
    
    MEMORIA_NODOS[1, 1] <- "101"
    MEMORIA_NODOS[1, 2] <- "Word"
    MEMORIA_NODOS[1, 3] <- "5"
    MEMORIA_NODOS[1, 5] <- "0"
    
    frente <- 1
    ultimoLibre <- 2
    
    Escribir "*** ENCOLAR POR PRIORIDAD ***"
    Escribir "Ingrese ID del proceso:"
    Leer nuevoId
    Escribir "Ingrese Nombre:"
    Leer nuevoNombre
    Escribir "Ingrese Prioridad (Prueba con un numero menor a 5 o mayor a 5):"
    Leer nuevaPrioridad
    
    nuevoNodo <- ultimoLibre
    MEMORIA_NODOS[nuevoNodo, 1] <- nuevoId
    MEMORIA_NODOS[nuevoNodo, 2] <- nuevoNombre
    MEMORIA_NODOS[nuevoNodo, 3] <- nuevaPrioridad
    MEMORIA_NODOS[nuevoNodo, 5] <- "0"
    ultimoLibre <- ultimoLibre + 1
    
    Si frente = 0 O ConvertirANumero(nuevaPrioridad) > ConvertirANumero(MEMORIA_NODOS[frente, 3]) Entonces
        MEMORIA_NODOS[nuevoNodo, 5] <- ConvertirATexto(frente)
        frente <- nuevoNodo
    Sino
        actual <- frente
        anterior <- 0
        Mientras actual <> 0 Y ConvertirANumero(MEMORIA_NODOS[actual, 3]) >= ConvertirANumero(nuevaPrioridad) Hacer
            anterior <- actual
            actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
        FinMientras
        MEMORIA_NODOS[nuevoNodo, 5] <- ConvertirATexto(actual)
        MEMORIA_NODOS[anterior, 5] <- ConvertirATexto(nuevoNodo)
    FinSi
    
    Escribir "Proceso encolado din�micamente."
    Escribir ""
    Escribir "=== RECORRIDO DE VERIFICACI�N (COLA) ==="
    actual <- frente
    Mientras actual <> 0 Hacer
        Escribir "Direcci�n [", actual, "] -> ID: ", MEMORIA_NODOS[actual, 1], " | Nombre: ", MEMORIA_NODOS[actual, 2], " | Prioridad: ", MEMORIA_NODOS[actual, 3], " | Siguiente apunta a: ", MEMORIA_NODOS[actual, 5]
        actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
    FinMientras
FinProceso