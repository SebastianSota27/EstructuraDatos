Proceso LiberarMemoriaPop
    Definir MEMORIA_NODOS Como Cadena
    Dimension MEMORIA_NODOS[100, 5] 
    Definir cabeza, frente, tope, ultimoLibre, i Como Entero
    Definir bloqueAux, actual Como Entero
    
    Para i <- 1 Hasta 100 Hacer
        MEMORIA_NODOS[i, 1] <- ""
        MEMORIA_NODOS[i, 5] <- "0"
    FinPara
  
    MEMORIA_NODOS[1, 1] <- "200"
    MEMORIA_NODOS[1, 2] <- "Sistema"
    MEMORIA_NODOS[1, 3] <- "4096"
    MEMORIA_NODOS[1, 5] <- "0"
    
    MEMORIA_NODOS[2, 1] <- "300"
    MEMORIA_NODOS[2, 2] <- "VirusTotal"
    MEMORIA_NODOS[2, 3] <- "512"
    MEMORIA_NODOS[2, 5] <- "1"
    
    tope <- 2
    
    Si tope = 0 Entonces
        Escribir "Pila de memoria vac�a."
    Sino
        bloqueAux <- tope
        Escribir "LIBERANDO TOPE (POP) -> Bloque del proceso: ", MEMORIA_NODOS[bloqueAux, 2], " | Tama�o: ", MEMORIA_NODOS[bloqueAux, 3], " KB"
        
        tope <- ConvertirANumero(MEMORIA_NODOS[tope, 5])
        MEMORIA_NODOS[bloqueAux, 1] <- ""
        MEMORIA_NODOS[bloqueAux, 5] <- "0"
        Escribir "Memoria liberada."
    FinSi
    
    Escribir ""
    Escribir "*** RECORRIDO DE VERIFICACI�N (NUEVO ESTADO PILA) ***"
    actual <- tope
    Si actual = 0 Entonces
        Escribir "La pila de memoria quedo vacia."
    Sino
        Mientras actual <> 0 Hacer
            Escribir "Tope Actual en Direcci�n [", actual, "] -> Proceso activo: ", MEMORIA_NODOS[actual, 2], " | Consumo: ", MEMORIA_NODOS[actual, 3], " KB | Abajo apunta a: ", MEMORIA_NODOS[actual, 5]
            actual <- ConvertirANumero(MEMORIA_NODOS[actual, 5])
        FinMientras
    FinSi
FinProceso